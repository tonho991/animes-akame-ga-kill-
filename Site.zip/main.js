var texto = document.getElementById('texto').value;

function click(){
  
  
  
  
 
    window.alert('olá');
    

  
}

